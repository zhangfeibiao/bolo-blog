title: Mac Catalina版本升级问题
date: '2020-07-05 22:36:12'
updated: '2020-08-30 03:57:00'
tags: [必备工具]
permalink: /1593959772687.html
---
![](https://b3logfile.com/bing/20180919.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 一、Catalina版本不能在根目录下写文件问题

Mac系统升级到Catalina之后，就不能在根目录下写文件了，比如：

```
sudo mkdir /data
mkdir: /data: Read-only file system
```

会提示出该目录只读，原先根目录的文件在系统更新后会放在桌面「迁移的项目」文件夹中，具体路径 /Users/Shared/Relocated\ Items/Security

**解决办法：**

1. 电脑关机重启按住command+R进入恢复模式，待出现apple进度条松手
2. 进度条加载完成之后，打开左上角窗口终端，输入命令csrutil disable，即关闭SIP（系统完整性保护）
3. 随后重启进入系统，命令终端上在自己的工作目录创建文件夹，如 sudo mkdir /Users/zhangfeibiao/data
4. 对根目录下的文件夹进行重新挂载，输入命令 sudo mount -uw /
5. 进行工作目录和根目录软连接，输入命令 sudo ln -s /Users/zhangfeibiao/data  /data
6. 将「迁移的项目」(若存桌面在该文件夹则操作此项) 中目标文件移动到刚刚创建的目录中， sudo cp -ri /Users/Shared/Relocated\ Items/Security/data/* /Users/zhangfeibiao/data
7. 重启计算机再次进入Recovery恢复模式，终端输入 csrutil enable，开启SIP

## 二、Mac升级后git终端无法使用

如图

```
 git --version
xcrun: error: invalid active developer path (/Library/Developer/CommandLineTools), missing xcrun at: /Library/Developer/CommandLineTools/usr/bin/xcrun
```

解决方法，重装xcode command line：

xcode-select --install

如果没有解决问题，执行以下命令

sudo xcode-select -switch /
